package mw.scheduler;

import java.io.IOException;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.apache.catalina.tribes.util.Arrays;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class URLChk implements Job
{
  public void execute(JobExecutionContext arg0)
    throws JobExecutionException
  {
    runURLChk();
  }

  public void runURLChk() {	  
	  System.out.println("쿼츠 주기적 실행 : " + java.text.SimpleDateFormat.getTimeInstance().toString());
//	  URLCheck urlCheck = new URLCheck();
//	  ArrayList<urlvo> errlist = urlCheck.urlcheck();
  }
		
}

